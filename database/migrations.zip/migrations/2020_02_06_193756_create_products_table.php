<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration {
	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up() {
		Schema::create('products', function (Blueprint $table) {
			$table->bigIncrements('id');
			$table->string('model_number');
			$table->string('measuring_unit');
			$table->string('name');
			$table->string('brand_name');
			$table->integer('stock_qty');
			$table->string('reorder_qty');
			$table->string('purchase_price');
			$table->string('selling_price');
			$table->string('location');
			$table->date('reg_date');
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down() {
		Schema::dropIfExists('products');
	}
}
